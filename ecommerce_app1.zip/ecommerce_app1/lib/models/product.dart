﻿class Product {
  final String id;
  final String name;
  final double price;
  final String category;
  final double rating;
  final int popularity;
  final String image;
  final String description; // ✅ Add missing description

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.category,
    required this.rating,
    required this.popularity,
    required this.image,
    required this.description, // ✅ Include description
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json["id"].toString(),
      name: json["title"],
      price: (json["price"] as num).toDouble(),
      category: json["category"],
      rating: (json["rating"]?["rate"] as num?)?.toDouble() ?? 0.0, // ✅ Handle null values
      popularity: json["rating"]?["count"] ?? 0, // ✅ Handle null values
      image: json["image"],
      description: json["description"] ?? "No description available", // ✅ Ensure description is included
    );
  }
}
