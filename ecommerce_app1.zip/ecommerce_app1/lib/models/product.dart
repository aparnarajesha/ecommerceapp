class Product {
  final String id;
  final String name;
  final double price;
  final String category;
  final double rating;
  final int popularity;
  final String image; // ? Add image back

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.category,
    required this.rating,
    required this.popularity,
    required this.image, // ? Include image
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json["id"].toString(),
      name: json["title"],
      price: json["price"].toDouble(),
      category: json["category"],
      rating: json["rating"]["rate"].toDouble(),
      popularity: json["rating"]["count"],
      image: json["image"], // ? Fetch image from API
    );
  }
}
