﻿class Validators {
  // ✅ Name Validation (At least 3 characters)
  static String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return '⚠ Name is required';
    }
    if (value.trim().length < 3) {
      return '⚠ Name must be at least 3 characters long';
    }
    return null; // ✅ Valid
  }

  // ✅ Email Validation (Valid format)
  static String? validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return '⚠ Email is required';
    }
    final RegExp emailRegex =
        RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    if (!emailRegex.hasMatch(value.trim())) {
      return '⚠ Enter a valid email address (e.g., example@email.com)';
    }
    return null; // ✅ Valid
  }

  // ✅ Phone Number Validation (10-digit Indian Number)
  static String? validatePhone(String? value) {
    if (value == null || value.trim().isEmpty) {
      return '⚠ Phone number is required';
    }
    final RegExp phoneRegex = RegExp(r'^[6-9]\d{9}$'); // Starts with 6-9, 10 digits
    if (!phoneRegex.hasMatch(value.trim())) {
      return '⚠ Enter a valid 10-digit phone number (India)';
    }
    return null; // ✅ Valid
  }

  // ✅ Password Validation (8+ characters, 1 uppercase, 1 number, 1 special character)
  static String? validatePassword(String? value) {
    if (value == null || value.trim().isEmpty) {
      return '⚠ Password is required';
    }
    if (value.length < 8) {
      return '⚠ Password must be at least 8 characters long';
    }
    final RegExp passwordRegex =
        RegExp(r'^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$');
    if (!passwordRegex.hasMatch(value)) {
      return '⚠ Password must include at least:\n• 1 Uppercase letter\n• 1 Number\n• 1 Special character (@\$!%*?&)';
    }
    return null; // ✅ Valid
  }
}
