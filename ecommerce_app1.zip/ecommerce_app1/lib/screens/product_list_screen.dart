﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import '../models/product.dart';

class ProductListScreen extends StatefulWidget {
  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  String? selectedSortOption;
  String? selectedCategory;
  double? minPrice, maxPrice, minRating;

  @override
  void initState() {
    super.initState();
    Provider.of<ProductProvider>(context, listen: false).fetchProducts();
  }

  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);
    final products = productProvider.products;

    return Scaffold(
      appBar: AppBar(
        title: Text("Products"),
        actions: [
          IconButton(
            icon: Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(productProvider),
          ),
        ],
      ),
      body: Column(
        children: [
          /// 🔹 **Sorting Dropdown**
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Sort by:",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                DropdownButton<String>(
                  value: selectedSortOption,
                  hint: Text("Select"),
                  items: ["price", "popularity", "rating"].map((String option) {
                    return DropdownMenuItem<String>(
                      value: option,
                      child: Text(option.toUpperCase()), // Display uppercase for better UI
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        selectedSortOption = newValue;
                        productProvider.sortProducts(newValue); // Sorting applied here
                      });
                    }
                  },
                ),
              ],
            ),
          ),

          /// 🔹 **Product List**
          Expanded(
            child: products.isEmpty
                ? Center(child: CircularProgressIndicator())
                : ListView.builder(
                    itemCount: products.length,
                    itemBuilder: (context, index) {
                      final product = products[index];
                      return ListTile(
                        title: Text(product.name),
                        subtitle: Text("\$${product.price} | ⭐ ${product.rating}"),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  /// 🔹 **Filter Dialog**
  void _showFilterDialog(ProductProvider provider) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Filter Products"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              /// Category Filter
              DropdownButton<String>(
                value: selectedCategory,
                hint: Text("Select Category"),
                items: ["Electronics", "Fashion", "Home"].map((category) {
                  return DropdownMenuItem(value: category, child: Text(category));
                }).toList(),
                onChanged: (value) {
                  setState(() => selectedCategory = value);
                },
              ),

              /// Price Range
              TextField(
                decoration: InputDecoration(labelText: "Min Price"),
                keyboardType: TextInputType.number,
                onChanged: (value) => minPrice = double.tryParse(value),
              ),
              TextField(
                decoration: InputDecoration(labelText: "Max Price"),
                keyboardType: TextInputType.number,
                onChanged: (value) => maxPrice = double.tryParse(value),
              ),

              /// Rating Filter
              TextField(
                decoration: InputDecoration(labelText: "Min Rating"),
                keyboardType: TextInputType.number,
                onChanged: (value) => minRating = double.tryParse(value),
              ),
            ],
          ),
          actions: [
            /// Clear Filters Button
            TextButton(
              onPressed: () {
                provider.clearFilters();
                setState(() {
                  selectedCategory = null;
                  minPrice = null;
                  maxPrice = null;
                  minRating = null;
                });
                Navigator.pop(context);
              },
              child: Text("Clear"),
            ),

            /// Apply Filters Button
            TextButton(
              onPressed: () {
                provider.filterProducts(
                  category: selectedCategory,
                  minPrice: minPrice,
                  maxPrice: maxPrice,
                  minRating: minRating,
                );
                Navigator.pop(context);
              },
              child: Text("Apply"),
            ),
          ],
        );
      },
    );
  }
}
