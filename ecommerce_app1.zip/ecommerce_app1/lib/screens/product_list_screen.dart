﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import '../models/product.dart';

class ProductListScreen extends StatefulWidget {
  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  String? selectedSort;
  String? selectedCategory;
  double? minPrice, maxPrice, minRating;

  @override
  void initState() {
    super.initState();
    Provider.of<ProductProvider>(context, listen: false).fetchProducts();
  }

  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);
    final products = productProvider.products;

    return Scaffold(
      appBar: AppBar(
        title: Text("Products"),
        actions: [
          IconButton(
            icon: Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(productProvider),
          ),
          IconButton(
            icon: Icon(Icons.sort),
            onPressed: () => _showSortOptions(productProvider),
          ),
        ],
      ),
      body: products.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return ListTile(
                  title: Text(product.name),
                  subtitle: Text("\$${product.price} | ⭐ ${product.rating}"),
                );
              },
            ),
    );
  }

  void _showSortOptions(ProductProvider provider) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            title: Text("Sort by Price"),
            onTap: () {
              provider.sortProducts("price");
              Navigator.pop(context);
            },
          ),
          ListTile(
            title: Text("Sort by Popularity"),
            onTap: () {
              provider.sortProducts("popularity");
              Navigator.pop(context);
            },
          ),
          ListTile(
            title: Text("Sort by Rating"),
            onTap: () {
              provider.sortProducts("rating");
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  void _showFilterDialog(ProductProvider provider) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Filter Products"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButton<String>(
                value: selectedCategory,
                hint: Text("Select Category"),
                items: ["Electronics", "Fashion", "Home"].map((category) {
                  return DropdownMenuItem(value: category, child: Text(category));
                }).toList(),
                onChanged: (value) {
                  setState(() => selectedCategory = value);
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: "Min Price"),
                keyboardType: TextInputType.number,
                onChanged: (value) => minPrice = double.tryParse(value),
              ),
              TextField(
                decoration: InputDecoration(labelText: "Max Price"),
                keyboardType: TextInputType.number,
                onChanged: (value) => maxPrice = double.tryParse(value),
              ),
              TextField(
                decoration: InputDecoration(labelText: "Min Rating"),
                keyboardType: TextInputType.number,
                onChanged: (value) => minRating = double.tryParse(value),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                provider.clearFilters();
                Navigator.pop(context);
              },
              child: Text("Clear"),
            ),
            TextButton(
              onPressed: () {
                provider.filterProducts(
                  category: selectedCategory,
                  minPrice: minPrice,
                  maxPrice: maxPrice,
                  minRating: minRating,
                );
                Navigator.pop(context);
              },
              child: Text("Apply"),
            ),
          ],
        );
      },
    );
  }
} 
