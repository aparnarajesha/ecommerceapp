﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/product_provider.dart';
import '../widgets/product_card.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late ScrollController _scrollController;
  late TextEditingController _searchController;
  bool _isSearching = false;
  bool _isLoadingMore = false;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _scrollController = ScrollController();

    // Fetch products when screen loads
    Future.microtask(() => Provider.of<ProductProvider>(context, listen: false).fetchProducts());

    _scrollController.addListener(_onScroll);
  }

  /// **Handles Infinite Scrolling**
  void _onScroll() {
    final productProvider = Provider.of<ProductProvider>(context, listen: false);
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 100) {
      if (!_isLoadingMore && !_isSearching) {
        _isLoadingMore = true;
        productProvider.fetchProducts(loadMore: true).then((_) {
          _isLoadingMore = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: Text("E-Commerce App"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              authProvider.logoutUser();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // 🔎 Search Bar
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              onChanged: (query) {
                setState(() => _isSearching = query.isNotEmpty);
                Provider.of<ProductProvider>(context, listen: false).searchProducts(query);
              },
              decoration: InputDecoration(
                hintText: "Search products...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),

          // 📌 Product List with Infinite Scrolling
          Expanded(
            child: Consumer<ProductProvider>(
              builder: (context, productProvider, child) {
                if (productProvider.isLoading && productProvider.products.isEmpty) {
                  return Center(child: CircularProgressIndicator()); // Show loader on first load
                }

                return ListView.builder(
                  controller: _scrollController,
                  itemCount: productProvider.products.length + (productProvider.isMoreLoading ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index < productProvider.products.length) {
                      return ProductCard(product: productProvider.products[index]);
                    } else {
                      return Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Center(child: CircularProgressIndicator()), // Show when loading more
                      );
                    }
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
