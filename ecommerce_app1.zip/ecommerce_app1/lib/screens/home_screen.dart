﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/product_provider.dart';
import '../providers/cart_provider.dart';
import '../widgets/product_card.dart';
import '../screens/login_screen.dart';
import '../screens/cart_screen.dart'; // ✅ Import CartScreen

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late ScrollController _scrollController;
  late TextEditingController _searchController;
  bool _isSearching = false;
  bool _isLoadingMore = false;
  String selectedSortOption = "Price"; // ✅ Default value

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _scrollController = ScrollController();

    Future.microtask(() {
      Provider.of<ProductProvider>(context, listen: false).fetchProducts();
    });

    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    final productProvider = Provider.of<ProductProvider>(context, listen: false);
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 100) {
      if (!_isLoadingMore && !_isSearching) {
        _isLoadingMore = true;
        productProvider.fetchProducts(loadMore: true).then((_) {
          setState(() {
            _isLoadingMore = false;
          });
        });
      }
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text("E-Commerce App"),
        actions: [
          // 🛒 Cart Icon with Badge
          Consumer<CartProvider>(
            builder: (context, cartProvider, child) {
              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.shopping_cart),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CartScreen()),
                      );
                    },
                  ),
                  if (cartProvider.cartItems.isNotEmpty) // ✅ Show badge only if cart has items
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          cartProvider.cartItems.length.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),

          // 🔑 Logout Button
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logoutUser();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // 🔎 Search Bar
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              onChanged: (query) {
                setState(() => _isSearching = query.isNotEmpty);
                Provider.of<ProductProvider>(context, listen: false).searchProducts(query);
              },
              decoration: InputDecoration(
                hintText: "Search products...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),

          // 🔽 Sorting Dropdown
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Sort by:", style: TextStyle(fontSize: 16)),
                DropdownButton<String>(
                  value: selectedSortOption,
                  items: ["Price", "Popularity", "Rating"].map((String option) {
                    return DropdownMenuItem<String>(
                      value: option,
                      child: Text(option),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        selectedSortOption = newValue;
                        Provider.of<ProductProvider>(context, listen: false).sortProducts(newValue);
                      });
                    }
                  },
                ),
              ],
            ),
          ),

          // 📌 Product List with Infinite Scrolling
          Expanded(
            child: Consumer<ProductProvider>(
              builder: (context, productProvider, child) {
                if (productProvider.isLoading && productProvider.products.isEmpty) {
                  return const Center(child: CircularProgressIndicator()); // Show loader on first load
                }

                return ListView.builder(
                  controller: _scrollController,
                  itemCount: productProvider.products.length + (productProvider.isMoreLoading ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index < productProvider.products.length) {
                      return ProductCard(product: productProvider.products[index]);
                    } else {
                      return const Padding(
                        padding: EdgeInsets.all(10.0),
                        child: Center(child: CircularProgressIndicator()), // Show when loading more
                      );
                    }
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
