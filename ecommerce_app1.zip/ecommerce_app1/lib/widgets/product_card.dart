﻿import 'package:flutter/material.dart';
import '../models/product.dart';
import '../screens/product_detail_screen.dart';

class ProductCard extends StatelessWidget {
  final Product product;

  ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        leading: Image.network(
          product.image, // ✅ Ensure `image` exists in `Product` model
          width: 50,
          height: 50,
          fit: BoxFit.cover,
        ),
        title: Text(product.name, // ✅ Use `name` instead of `title`
            maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("\$${product.price}",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.green)),
            Row(
              children: [
                Icon(Icons.star, color: Colors.amber, size: 16),
                Text(" ${product.rating} (${product.popularity} reviews)"), // ✅ Use `popularity` instead of `ratingCount`
              ],
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ProductDetailScreen(product: product)),
          );
        },
      ),
    );
  }
}
