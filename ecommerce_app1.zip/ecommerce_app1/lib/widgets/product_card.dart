﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../screens/product_detail_screen.dart';
import '../providers/cart_provider.dart';

class ProductCard extends StatelessWidget {
  final Product product;

  ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context, listen: false);

    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        leading: Image.network(
          product.image,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
        ),
        title: Text(product.name,
            maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("\$${product.price}",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.green)),
            Row(
              children: [
                Icon(Icons.star, color: Colors.amber, size: 16),
                Text(" ${product.rating} (${product.popularity} reviews)"),
              ],
            ),
          ],
        ),
        trailing: IconButton(
          icon: Icon(Icons.add_shopping_cart, color: Colors.blue),
          onPressed: () {
            cartProvider.addToCart(product);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text("${product.name} added to cart!"),
                duration: Duration(seconds: 1),
              ),
            );
          },
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ProductDetailScreen(product: product)),
          );
        },
      ),
    );
  }
}
