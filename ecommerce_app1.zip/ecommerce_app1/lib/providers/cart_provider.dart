﻿import 'package:flutter/material.dart';
import '../models/product.dart';

class CartProvider with ChangeNotifier {
  final Map<String, CartItem> _cartItems = {}; // Store items with unique IDs

  Map<String, CartItem> get cartItems => _cartItems;

  /// **🛒 Add Item to Cart (Increase quantity if exists)**
  void addToCart(Product product) {
    if (_cartItems.containsKey(product.id)) {
      // ✅ If the product is already in the cart, just increase the quantity
      _cartItems[product.id]!.increaseQuantity();
    } else {
      // ✅ If it's a new product, add it to the cart
      _cartItems[product.id] = CartItem(
        id: product.id,
        name: product.name,
        image: product.image, // ✅ Ensure product image is stored
        price: product.price,
        quantity: 1,
      );
    }
    notifyListeners(); // 🔄 Notify UI to update
  }

  /// **📉 Remove or Decrease Item Quantity**
  void removeFromCart(String productId) {
    if (_cartItems.containsKey(productId)) {
      _cartItems[productId]!.decreaseQuantity();
      if (_cartItems[productId]!.quantity == 0) {
        _cartItems.remove(productId);
      }
    }
    notifyListeners();
  }

  /// **💰 Get Total Price**
  double get totalPrice =>
      _cartItems.values.fold(0.0, (sum, item) => sum + item.totalPrice);

  /// **🔢 Get Quantity of a Specific Item**
  int getQuantity(String productId) => _cartItems[productId]?.quantity ?? 0;

  /// **🛒 Clear Cart After Checkout**
  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }
}

/// **📦 Cart Item Model**
class CartItem {
  final String id;
  final String name;
  final String image; // ✅ Added image field
  final double price;
  int quantity;

  CartItem({
    required this.id,
    required this.name,
    required this.image,
    required this.price,
    this.quantity = 1,
  });

  double get totalPrice => price * quantity;

  void increaseQuantity() => quantity++;

  void decreaseQuantity() {
    if (quantity > 0) quantity--;
  }
}
