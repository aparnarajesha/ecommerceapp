﻿import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  final FlutterSecureStorage _storage = FlutterSecureStorage();

  String? _token;
  bool _isAuthenticated = false;
  String? _userName;
  String? _userPhone;

  bool get isAuthenticated => _isAuthenticated;
  String? get token => _token;
  String? get userName => _userName;
  String? get userPhone => _userPhone;

  /// ✅ Initialize Authentication State
  Future<void> initializeAuth() async {
    await loadUserDetails();
  }

  /// ✅ Load User Details from Secure Storage
  Future<void> loadUserDetails() async {
    _token = await _storage.read(key: "token");
    _userName = await _storage.read(key: "userName");
    _userPhone = await _storage.read(key: "userPhone");

    _isAuthenticated = _token != null;
    notifyListeners();
  }

  /// ✅ Register User
  Future<bool> registerUser(String email, String password) async {
    final response = await _authService.registerUser(email, password);
    if (response["success"]) {
      _token = response["data"]["token"];
      _isAuthenticated = true;
      await _storage.write(key: "token", value: _token);
      notifyListeners();
      return true;
    }
    return false;
  }

  /// ✅ Store User Name & Phone Locally
  Future<void> storeUserDetails(String name, String phone) async {
    await _storage.write(key: "userName", value: name);
    await _storage.write(key: "userPhone", value: phone);
    _userName = name;
    _userPhone = phone;
    notifyListeners();
  }

  /// ✅ Login User
  Future<bool> loginUser(String email, String password) async {
    final response = await _authService.loginUser(email, password);
    if (response["success"]) {
      _token = response["token"];
      _isAuthenticated = true;
      await _storage.write(key: "token", value: _token);
      await loadUserDetails(); // ✅ Load stored user details
      notifyListeners();
      return true;
    }
    return false;
  }

  /// ✅ Logout User
  Future<void> logoutUser() async {
    await _authService.logoutUser();
    await _storage.deleteAll(); // Clears all stored user data
    _token = null;
    _userName = null;
    _userPhone = null;
    _isAuthenticated = false;
    notifyListeners();
  }
}
 