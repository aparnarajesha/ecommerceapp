﻿import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/product.dart';

class ProductProvider with ChangeNotifier {
  List<Product> _products = [];
  List<Product> _allProducts = [];
  List<Product> _filteredProducts = [];
  int _currentIndex = 0;
  bool _isLoading = false;
  bool _isMoreLoading = false;

  List<Product> get products => _filteredProducts.isNotEmpty ? _filteredProducts : _products;
  bool get isLoading => _isLoading;
  bool get isMoreLoading => _isMoreLoading;

  final String _apiUrl = 'https://fakestoreapi.com/products';

  /// **1️⃣ Fetch Products (Initial & Pagination)**
  Future<void> fetchProducts({bool loadMore = false}) async {
    if (loadMore) {
      if (_products.length < 10) return; // Ensure at least 10 products exist before looping
      _isMoreLoading = true;
      notifyListeners();
      await Future.delayed(Duration(milliseconds: 500)); // Simulate loading time
      _loopProducts(); // Repeat products
      _isMoreLoading = false;
      notifyListeners();
      return;
    }

    _isLoading = true;
    notifyListeners();

    try {
      if (_allProducts.isEmpty) {
        // Fetch only if not already fetched
        final response = await http.get(Uri.parse(_apiUrl));
        if (response.statusCode == 200) {
          _allProducts = (json.decode(response.body) as List)
              .map((data) => Product.fromJson(data))
              .toList();
        }
      }

      if (_allProducts.isNotEmpty) {
        _products = _allProducts.take(10).toList(); // Load first 10 products
        _currentIndex = 10; // Start from the 11th product for pagination
      }
    } catch (error) {
      print("Error fetching products: $error");
    }

    _isLoading = false;
    notifyListeners();
  }

  /// **2️⃣ Load More Products & Loop When End is Reached**
  void _loopProducts() {
    List<Product> newProducts = [];
    for (int i = 0; i < 10; i++) {
      newProducts.add(_allProducts[_currentIndex % _allProducts.length]); // Loop products
      _currentIndex++;
    }
    _products.addAll(newProducts);
    notifyListeners();
  }

  /// **3️⃣ Search Products**
  void searchProducts(String query) {
    if (query.isEmpty) {
      _filteredProducts = _allProducts.take(10).toList(); // Reset to first 10 products
    } else {
      _filteredProducts = _allProducts
          .where((product) =>
              product.name.toLowerCase().contains(query.toLowerCase())) // ✅ Use name
          .toList();
    }
    notifyListeners();
  }

  /// **4️⃣ Sorting Products**
  void sortProducts(String criteria) {
    if (criteria == "price") {
      _filteredProducts.sort((a, b) => a.price.compareTo(b.price));
    } else if (criteria == "popularity") {
      _filteredProducts.sort((a, b) => b.popularity.compareTo(a.popularity)); // ✅ Use popularity
    } else if (criteria == "rating") {
      _filteredProducts.sort((a, b) => b.rating.compareTo(a.rating));
    }
    notifyListeners();
  }

  /// **5️⃣ Filtering Products**
  void filterProducts({String? category, double? minPrice, double? maxPrice, double? minRating}) {
    _filteredProducts = _products.where((product) {
      final matchesCategory = category == null || product.category == category;
      final matchesPrice = (minPrice == null || product.price >= minPrice) &&
                           (maxPrice == null || product.price <= maxPrice);
      final matchesRating = minRating == null || product.rating >= minRating;
      return matchesCategory && matchesPrice && matchesRating;
    }).toList();
    notifyListeners();
  }

  /// **6️⃣ Clear Filters**
  void clearFilters() {
    _filteredProducts = _products;
    notifyListeners();
  }
} 