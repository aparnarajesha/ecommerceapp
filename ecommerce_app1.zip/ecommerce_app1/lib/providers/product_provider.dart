﻿import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/product.dart';

class ProductProvider with ChangeNotifier {
  List<Product> _products = [];
  List<Product> _allProducts = [];
  List<Product> _filteredProducts = [];
  int _currentIndex = 0;
  bool _isLoading = false;
  bool _isMoreLoading = false;
  String? _currentSortOption;

  List<Product> get products => _filteredProducts.isNotEmpty ? _filteredProducts : _products;
  bool get isLoading => _isLoading;
  bool get isMoreLoading => _isMoreLoading;

  final String _apiUrl = 'https://fakestoreapi.com/products';

  /// **1️⃣ Fetch Products (Initial & Pagination)**
  Future<void> fetchProducts({bool loadMore = false}) async {
    if (loadMore) {
      if (_products.length < 10) return; // Ensure at least 10 products exist before looping
      _isMoreLoading = true;
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 500)); // Simulate loading time
      _loopProducts(); // Load more products
      _isMoreLoading = false;
      notifyListeners();
      return;
    }

    _isLoading = true;
    notifyListeners();

    try {
      if (_allProducts.isEmpty) {
        // Fetch only if not already fetched
        final response = await http.get(Uri.parse(_apiUrl));
        if (response.statusCode == 200) {
          _allProducts = (json.decode(response.body) as List)
              .map((data) => Product.fromJson(data))
              .toList();
        }
      }

      if (_allProducts.isNotEmpty) {
        _products = List.from(_allProducts.take(10)); // Load first 10 products
        _currentIndex = 10; // Start from the 11th product for pagination
      }
    } catch (error) {
      print("Error fetching products: $error");
    }

    _applySorting(); // ✅ Ensure sorting is applied after fetch
    _isLoading = false;
    notifyListeners();
  }

  /// **2️⃣ Load More Products & Loop When End is Reached**
  void _loopProducts() {
    if (_allProducts.isEmpty) return; // Ensure products are available

    List<Product> newProducts = [];
    for (int i = 0; i < 10; i++) {
      newProducts.add(_allProducts[_currentIndex % _allProducts.length]); // Loop products
      _currentIndex++;
    }
    _products.addAll(newProducts);
    _applySorting(); // ✅ Apply sorting after adding new products
    notifyListeners();
  }

  /// **3️⃣ Search Products**
  void searchProducts(String query) {
    if (query.isEmpty) {
      _filteredProducts = [];
    } else {
      _filteredProducts = _allProducts
          .where((product) =>
              product.name.toLowerCase().contains(query.toLowerCase())) // ✅ Use name
          .toList();
    }
    _applySorting(); // ✅ Apply sorting after search
    notifyListeners();
  }

  /// **4️⃣ Sorting Products**
  void sortProducts(String criteria) {
    _currentSortOption = criteria;
    _applySorting();
  }

  /// **Helper: Apply Sorting**
  void _applySorting() {
    List<Product> sortingTarget = _filteredProducts.isNotEmpty ? _filteredProducts : _products;

    if (_currentSortOption == "Price") {
      sortingTarget.sort((a, b) => a.price.compareTo(b.price));
    } else if (_currentSortOption == "Popularity") {
      sortingTarget.sort((a, b) => b.popularity.compareTo(a.popularity));
    } else if (_currentSortOption == "Rating") {
      sortingTarget.sort((a, b) => b.rating.compareTo(a.rating));
    }
    
    notifyListeners();
  }

  /// **5️⃣ Filtering Products**
  void filterProducts({String? category, double? minPrice, double? maxPrice, double? minRating}) {
    if (category == null && minPrice == null && maxPrice == null && minRating == null) {
      _filteredProducts = [];
    } else {
      _filteredProducts = _allProducts.where((product) {
        final matchesCategory = category == null || product.category == category;
        final matchesPrice = (minPrice == null || product.price >= minPrice) &&
                             (maxPrice == null || product.price <= maxPrice);
        final matchesRating = minRating == null || product.rating >= minRating;
        return matchesCategory && matchesPrice && matchesRating;
      }).toList();
    }

    _applySorting(); // ✅ Apply sorting after filtering
    notifyListeners();
  }

  /// **6️⃣ Clear Filters**
  void clearFilters() {
    _filteredProducts = [];
    _applySorting(); // ✅ Apply sorting after clearing filters
    notifyListeners();
  }

  /// **7️⃣ Fetch a Product by ID (Fixed Error)**
  Product? getProductById(String productId) {
    try {
      return _allProducts.firstWhere(
        (product) => product.id == productId,
        orElse: () => Product(
          id: productId, // ✅ Ensure id is always a string
          name: "Unknown Product",
          price: 0.0,
          image: "https://via.placeholder.com/150",
          category: "Unknown",
          description: "No description available", // ✅ Fixed: Required field added
          rating: 0.0,
          popularity: 0,
        ),
      );
    } catch (e) {
      print("Error finding product by ID: $e");
      return null; // Return null if no matching product is found
    }
  }
}
