﻿import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthService {
  final Dio _dio = Dio();
  final String baseUrl = "https://reqres.in/api"; // Replace with actual backend URL
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  /// ✅ Helper method for API requests
  Future<Map<String, dynamic>> _postRequest(String endpoint, Map<String, dynamic> data) async {
    try {
      final response = await _dio.post(
        "$baseUrl/$endpoint",
        data: jsonEncode(data),
        options: Options(headers: {"Content-Type": "application/json"}),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return {"success": true, "data": response.data};
      } else {
        return {"success": false, "message": "Request failed with status: ${response.statusCode}"};
      }
    } on DioException catch (e) {
      return {"success": false, "message": e.response?.data["error"] ?? "An error occurred"};
    } catch (e) {
      return {"success": false, "message": "Unexpected error: ${e.toString()}"};
    }
  }

  /// ✅ Register User
  Future<Map<String, dynamic>> registerUser(String email, String password) async {
    return await _postRequest("register", {"email": email, "password": password});
  }

  /// ✅ Login User
  Future<Map<String, dynamic>> loginUser(String email, String password) async {
    final result = await _postRequest("login", {"email": email, "password": password});

    if (result["success"]) {
      String token = result["data"]["token"];
      await _storage.write(key: "token", value: token); // Store token
      return {"success": true, "message": "Login successful", "token": token};
    }

    return result;
  }

  /// ✅ Logout User
  Future<void> logoutUser() async {
    await _storage.deleteAll(); // Clears all stored data securely
  }

  /// ✅ Get Auth Token
  Future<String?> getAuthToken() async {
    return await _storage.read(key: "token");
  }

  /// ✅ Check if User is Logged In
  Future<bool> isUserLoggedIn() async {
    String? token = await getAuthToken();
    return token != null;
  }
}
