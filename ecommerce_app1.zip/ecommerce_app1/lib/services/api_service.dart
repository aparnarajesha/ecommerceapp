import 'package:dio/dio.dart';
import '../models/product.dart';

class ApiService {
  static final Dio _dio = Dio();
  static final String _baseUrl = "https://fakestoreapi.com/products";

  static Future<List<Product>> getProducts() async {
    final response = await _dio.get(_baseUrl);
    return (response.data as List).map((json) => Product.fromJson(json)).toList();
  }
}
